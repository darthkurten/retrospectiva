
$('.nav li a').click(function(){
	$('.nav li a').removeClass("actived");
	$(this).addClass("actived");
});
